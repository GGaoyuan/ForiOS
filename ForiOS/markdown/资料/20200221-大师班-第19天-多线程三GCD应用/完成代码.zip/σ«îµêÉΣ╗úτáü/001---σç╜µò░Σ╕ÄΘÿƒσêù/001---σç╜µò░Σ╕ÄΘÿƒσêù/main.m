//
//  main.m
//  001---函数与队列
//
//  Created by Cooci on 2018/6/21.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <pthread.h>
#import "AppDelegate.h"

void* pthreadTestMethod(void *);
int main(int argc, char * argv[]) {
    @autoreleasepool {
//        pthread_t thread = NULL;
//        char* str = "Cooci";
//        pthread_create(&thread, NULL, pthreadTestMethod, str);
//        
//        NSThread *t = [[NSThread alloc] initWithBlock:^{
//            NSLog(@"我开的线程");
//        }];
//        [t setName:@"第二条"];
//        [t start];
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

void * pthreadTestMethod(void *op){
    NSLog(@"我来了--%s",op);
    return NULL;
}
