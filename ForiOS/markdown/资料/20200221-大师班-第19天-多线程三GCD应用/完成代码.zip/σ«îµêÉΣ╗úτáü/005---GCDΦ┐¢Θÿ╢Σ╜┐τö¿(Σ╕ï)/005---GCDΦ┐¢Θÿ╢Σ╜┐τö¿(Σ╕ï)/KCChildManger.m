//
//  KCChildManger.m
//  005---GCD进阶使用(下)
//
//  Created by Cooci on 2018/7/2.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import "KCChildManger.h"

@implementation KCChildManger
+ (void)initialize{
    NSLog(@"子类");
}
@end
