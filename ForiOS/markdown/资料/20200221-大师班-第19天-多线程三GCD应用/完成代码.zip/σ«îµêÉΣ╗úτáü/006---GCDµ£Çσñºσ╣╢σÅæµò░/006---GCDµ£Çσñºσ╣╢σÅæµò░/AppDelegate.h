//
//  AppDelegate.h
//  006---GCD最大并发数
//
//  Created by Cooci on 2018/7/11.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

