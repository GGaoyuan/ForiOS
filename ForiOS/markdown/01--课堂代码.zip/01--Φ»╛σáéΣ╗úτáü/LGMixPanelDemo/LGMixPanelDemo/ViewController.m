//
//  ViewController.m
//  LGMixPanelDemo
//
//  Created by Cooci on 2019/08/12.
//  Copyright © 2019 LGEDU. All rights reserved.
//

#import "ViewController.h"
#import "LGPerson.h"

@interface ViewController ()

@property (nonatomic, strong) LGPerson *person;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    _person = [LGPerson new];
//    [_person eat];
    
    
    // 手势 请求 web
    // web 连接成功 信息
    // 信息 - 服务器
    // 手机 - snapshot
    // web 动作 - websocket
    // 手机 - log 反馈
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
//    NSLog(@"MainVC Coming");
}



@end
