//
//  LGPerson.m
//  LGMixPanelDemo
//
//  Created by vampire on 2019/11/13.
//  Copyright © 2019 LGEDU. All rights reserved.
//

#import "LGPerson.h"

@implementation LGPerson

@end
