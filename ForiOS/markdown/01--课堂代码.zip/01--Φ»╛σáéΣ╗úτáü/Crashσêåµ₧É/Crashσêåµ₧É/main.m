//
//  main.m
//  Crash分析
//
//  Created by cooci on 2019/5/31.
//  Copyright © 2019 lgcooci. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
