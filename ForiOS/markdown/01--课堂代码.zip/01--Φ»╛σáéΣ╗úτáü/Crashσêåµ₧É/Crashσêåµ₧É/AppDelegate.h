//
//  AppDelegate.h
//  Crash分析
//
//  Created by cooci on 2019/5/31.
//  Copyright © 2019 lgcooci. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

