//
//  ViewController.m
//  Crash分析
//
//  Created by cooci on 2019/5/31.
//  Copyright © 2019 lgcooci. All rights reserved.
//

#import "ViewController.h"
#import "LGUncaughtExceptionHandle.h"

@interface ViewController ()
@property (nonatomic, strong) NSArray *dataArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // 异常
    self.dataArray = @[@"逻辑教育-iOS底层大师班",@"数据结构算法",@"Flutter高级",@"视觉全训班"];
}

- (IBAction)exceptionAction:(id)sender {
    NSLog(@"%@",self.dataArray[5]);
}

// runtime


@end
