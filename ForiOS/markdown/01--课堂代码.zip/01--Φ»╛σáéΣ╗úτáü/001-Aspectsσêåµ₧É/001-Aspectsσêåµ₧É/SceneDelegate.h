//
//  SceneDelegate.h
//  001-Aspects分析
//
//  Created by Cooci on 2019/10/8.
//  Copyright © 2019 Cooci. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

