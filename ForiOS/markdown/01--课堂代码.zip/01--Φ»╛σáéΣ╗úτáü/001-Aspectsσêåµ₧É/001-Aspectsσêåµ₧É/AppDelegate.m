//
//  AppDelegate.m
//  001-Aspects分析
//
//  Created by Cooci on 2019/10/8.
//  Copyright © 2019 Cooci. All rights reserved.
//

#import "AppDelegate.h"
#import <Aspects/Aspects.h>
#import "ViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    // block () - 业务中心
    // apsect - hook 对象方法
    // 下 切片
    // viewDidLoad 插入一些东西 在它之前之后
    // block invocation 消息转发 -
    // block() -  invocation.invoke - 对象 target
    
    // sel - 切片 关联起来
    
    // 代码埋点 - method-swilzing
    // viewDidLoad - vc - load
    // 侵入性
    // 埋点 统计 - 分析 - app
    
    // 切面编程  思想设计
    // aop -> oop 强大的补充
    
    // 思想
    [ViewController aspect_hookSelector:@selector(tableView:didSelectRowAtIndexPath:) withOptions:AspectPositionAfter usingBlock:^(id<AspectInfo> aspectInfo){
        NSLog(@"View Controller %@ viewDidLoad", aspectInfo.instance);
        // 业务插入
        // 埋点 - 统计 - 点击是哪个tableview
        // 反馈出来 - 
        
        
    } error:NULL];

    [ViewController aspect_hookSelector:@selector(sayHello) withOptions:AspectPositionAfter usingBlock:^(id<AspectInfo> aspectInfo){
        NSLog(@"View Controller %@ viewDidLoad", aspectInfo.instance);
    } error:NULL];
    
    return YES;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
