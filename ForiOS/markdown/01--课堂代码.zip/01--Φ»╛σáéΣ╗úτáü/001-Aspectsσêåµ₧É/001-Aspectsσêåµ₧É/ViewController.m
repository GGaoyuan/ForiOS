//
//  ViewController.m
//  001-Aspects分析
//
//  Created by Cooci on 2019/10/8.
//  Copyright © 2019 Cooci. All rights reserved.
//



#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"%@ - %@",self,NSStringFromSelector(_cmd));
    
    [ViewController sayHello];
}

+ (void)sayHello{
    NSLog(@"%@ - %@",self,NSStringFromSelector(_cmd));
}


@end
