// This source file is part of the Swift.org open source project
//
// Copyright (c) 2017 - 2018 Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See http://swift.org/LICENSE.txt for license information
// See http://swift.org/CONTRIBUTORS.txt for the list of Swift project authors
//

#if !DEPLOYMENT_RUNTIME_OBJC && canImport(SwiftFoundation) && canImport(SwiftFoundationNetworking) && canImport(SwiftFoundationXML)
import SwiftFoundation
import SwiftFoundationNetworking
import SwiftFoundationXML
import CoreFoundation

#else
import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#endif
#if os(Windows)
import WinSDK
#endif


    
var threadRunLoop: CFRunLoop?
var runLoopSource: CFRunLoopSource?

let thread = Thread {
    threadRunLoop = RunLoop.current.getCFRunLoop()
        
     let performWork: (@convention(c) (UnsafeMutableRawPointer?) -> Void)! = { context in
         autoreleasepool {
            print("TestThread")
//             CFRunLoopWakeUp(CFRunLoopGetCurrent())
         }
     }

    var context = CFRunLoopSourceContext( version: 0, info:  nil, retain: nil, release: nil, copyDescription: nil, equal: nil, hash: nil, schedule: nil, cancel: nil, perform: performWork)
    runLoopSource = CFRunLoopSourceCreate(kCFAllocatorDefault, 0, &context)
    CFRunLoopAddSource(threadRunLoop, runLoopSource!, kCFRunLoopCommonModes)
    RunLoop.current.run()
}
thread.name = "TestThread"
thread.start()



let timer = Timer(timeInterval: 10, repeats: true) { _ in
    print("\(RunLoop.current)")
//        CFRunLoopSourceSignal(runLoopSource!)
//        CFRunLoopWakeUp(threadRunLoop!)
}
//    timer.tolerance = 100
RunLoop.current.add(timer, forMode: .common)
RunLoop.current.run()



